package com.br.AthuService.services;

import java.util.Date;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.br.AthuService.Data.UserEntity;
import com.br.AthuService.model.CredentialDto;
import com.br.AthuService.model.UserDto;

@Service
public interface UserService {
	Boolean addUser(CredentialDto dto);
	
	Date getLastLoginDate(String username);
	
	Set<UserDto> findAll();
}
