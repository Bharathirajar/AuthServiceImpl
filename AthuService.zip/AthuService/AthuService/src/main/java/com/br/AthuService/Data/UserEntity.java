package com.br.AthuService.Data;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tb_user")
public class UserEntity {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	@Column(name="username")
	private String userName;
	
	@Column(name="password_hash")
	private String passwordhash;
	
	@Column(name="login_time")
	private Date loginTime;
	
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getId() {
		return this.id;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getUserName() {
		return this.userName;
	}
	
	public void setLoginTime(Date loginTime)  {
		this.loginTime = loginTime;
	}
	
	public Date getLoginTime() {
		return this.loginTime;
	}
	
	public void setPasswordHash(String hash) {
		this.passwordhash = hash;
	}
	
	public String getPasswordHash() {
		return this.passwordhash;
	}
}
