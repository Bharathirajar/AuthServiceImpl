package com.br.AthuService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.br.AthuService.Data.UserEntity;
import com.br.AthuService.Data.RepositoryService.UserDataService;
import com.br.AthuService.services.Impl.UserServiceImpl;

@SpringBootApplication
@ComponentScan(basePackages= {"com.br.AthuService"})
//@EnableJpaRepositories(basePackages = {"Data.RepositoryService"})
public class AthuServiceApplication {

	@Autowired
	private UserDataService userDataService;
	
	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		ctx.register(UserServiceImpl.class);
		SpringApplication.run(AthuServiceApplication.class, args);
	}
	
	/*@Bean
	public com.br.AthuService.services.UserService UserService() {
		return new UserServiceImpl(this.userDataService);
	}*/
	
	/*@Bean
	public UserDataService userDataService() {
		return new JpaRepository<UserEntity, String>();
	}*/
}
