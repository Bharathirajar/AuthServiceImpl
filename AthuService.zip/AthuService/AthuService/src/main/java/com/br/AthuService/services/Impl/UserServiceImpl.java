package com.br.AthuService.services.Impl;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.br.AthuService.Data.UserEntity;
import com.br.AthuService.Data.RepositoryService.UserDataService;
import com.br.AthuService.model.CredentialDto;
import com.br.AthuService.model.UserDto;
import com.br.AthuService.services.UserService;

@Component
public class UserServiceImpl implements UserService {

	private UserDataService userDataService;

	public UserServiceImpl(UserDataService userDataService) {
		this.userDataService = userDataService;
	}
	
	@Override
	public Boolean addUser(CredentialDto dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Date getLastLoginDate(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<UserDto> findAll() {
		Set<UserDto> users = new HashSet<UserDto>();
		for(UserEntity row : userDataService.findAll()) {
			UserDto dto = new UserDto();
			dto.setUsername(row.getUserName());
			dto.setLastLogin(row.getLoginTime());
			users.add(dto);
		}
		return users;
	}

}
