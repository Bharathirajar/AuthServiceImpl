package com.br.AthuService.Data.RepositoryService;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.br.AthuService.Data.UserEntity;

@Repository
@Service
@Transactional
public interface UserDataService extends JpaRepository<UserEntity, String> {
	UserEntity findByUserName(String username);
}
