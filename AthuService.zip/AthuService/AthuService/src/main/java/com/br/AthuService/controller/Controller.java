package com.br.AthuService.controller;

import java.util.Date;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.br.AthuService.Data.UserEntity;
import com.br.AthuService.Data.RepositoryService.UserDataService;
import com.br.AthuService.model.CredentialDto;
import com.br.AthuService.model.UserDto;
import com.br.AthuService.services.UserService;

@RestController
public class Controller {

	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDataService userDataService;
	
	public Controller(UserService userService) {
		this.userService = userService;
	}
	
	private PasswordEncoder encrypt = new BCryptPasswordEncoder();
	
	@RequestMapping("/")
	public String testadd(){
		return "check";
	}
	
	@RequestMapping("/all")
	public Set<UserDto> getAll(){
		return userService.findAll();
	}
	
	@RequestMapping("/addUser")
	public void add(@RequestBody CredentialDto credentialDto) {
		UserEntity entity = new UserEntity();
		entity.setUserName(credentialDto.getUserName());
		entity.setPasswordHash(encrypt.encode(credentialDto.getPassword()));
		userDataService.save(entity);
	}
	
	@RequestMapping("/addLogin")
	public Boolean login(@RequestBody CredentialDto credentialDto) {
		UserEntity entity = userDataService.findByUserName(credentialDto.getUserName());
		if(encrypt.matches(credentialDto.getPassword(), entity.getPasswordHash())) {
			entity.setLoginTime(new Date());
			return true;
		}
		return false;
	}
}

