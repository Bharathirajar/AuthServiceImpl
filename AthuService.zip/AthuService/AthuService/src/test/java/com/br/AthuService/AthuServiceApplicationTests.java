package com.br.AthuService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AthuServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
